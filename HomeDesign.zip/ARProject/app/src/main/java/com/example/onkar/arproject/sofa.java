package com.example.onkar.arproject;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class sofa extends AppCompatActivity {

    ListView listView1;
    String s;
    String[] country={"sofa 1","sofa 2","sofa 3"};
    int[] lion= {R.drawable.couch,
            R.drawable.chair2,
            R.drawable.chairobj,
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        listView1=findViewById(R.id.listview);
        MyAdapter myAdapter=new MyAdapter(this,country,lion);
        listView1.setAdapter(myAdapter);
        // imageView=(ImageView)findViewById(R.id.imageView3);
        // listView[0].setOnItemClickListener
        listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Intent intent=new Intent(sofa.this,MainActivity.class);

                //Intent intent=new Intent(,Main2Activity.class);
                switch (i)
                {
                    case 0:
                        s="Couch.sfb";
                        break;
                    case 1:
                        s="Chair2.sfb";
                        break;
                    case 2:
                        s="chairobj.sfb";
                        break;
                }
                intent.putExtra("one",s);
                startActivity(intent);
            }
        });

    }
}
