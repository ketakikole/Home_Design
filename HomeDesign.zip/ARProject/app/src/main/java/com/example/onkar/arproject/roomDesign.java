package com.example.onkar.arproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class roomDesign extends AppCompatActivity {

    ListView listView;
    String s;
    String[] country={"room design 1","room design 2","room design 3"};
    int[] lion={R.drawable.room1,
            R.drawable.bedroom,
            R.drawable.bedroom,
            };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_design);
        listView=findViewById(R.id.listview);
        MyAdapter1 myAdapter=new MyAdapter1(this,country,lion);
        listView.setAdapter(myAdapter);
        // imageView=(ImageView)findViewById(R.id.imageView3);
        // listView[0].setOnItemClickListener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Intent intent=new Intent(roomDesign.this,MainActivity.class);

                //Intent intent=new Intent(,Main2Activity.class);
                switch (i)
                {
                    case 0:
                        s="room1.sfb";
                        break;
                    case 1:
                        s="2 bedroom.sfb";
                        break;
                    case 2:
                        s="chairobj.sfb";
                        break;
                }
                intent.putExtra("one",s);
                startActivity(intent);
            }
        });

    }
}