package com.example.onkar.arproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class table extends AppCompatActivity {

    ListView listView;
    String s;
    String[] country={"table 1","table 2","table 3"," table 4"};
    int[] lion={R.drawable.credenza,
            R.drawable.desk,
            R.drawable.table,
            R.drawable.table};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table);
        listView=findViewById(R.id.listview);
        MyAdapter2 myAdapter=new MyAdapter2(this,country,lion);
        listView.setAdapter(myAdapter);
        // imageView=(ImageView)findViewById(R.id.imageView3);
        // listView[0].setOnItemClickListener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Intent intent=new Intent(table.this,MainActivity.class);

                //Intent intent=new Intent(,Main2Activity.class);
                switch (i)
                {
                    case 0:
                        s="Credenza.sfb";
                        break;
                    case 1:
                        s="Desk.sfb";
                        break;
                    case 2:
                        s="Table.sfb";
                        break;
                    case 3:
                        s="Table Chairs.sfb";
                        break;
                }
                intent.putExtra("one",s);
                startActivity(intent);
            }
        });

    }
}
