package com.example.onkar.arproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class Main2Activity extends AppCompatActivity {

    ListView listView1;
    String s;
    String[] country={"Chair1","Chair 2","Chair 3","d"};
    int[] lion={R.drawable.b,
            R.drawable.b,
            R.drawable.b,
            R.drawable.b};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        listView1=findViewById(R.id.listview);
        MyAdapter myAdapter=new MyAdapter(this,country,lion);
        listView1.setAdapter(myAdapter);
        // imageView=(ImageView)findViewById(R.id.imageView3);
        // listView[0].setOnItemClickListener
        listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Intent intent=new Intent(Main2Activity.this,MainActivity.class);

                //Intent intent=new Intent(,Main2Activity.class);
                switch (i)
                {
                    case 0:
                        s="Chair1.sfb";
                        break;
                    case 1:
                        s="model.sfb";
                        break;
                    case 2:
                        s="chairobj.sfb";
                        break;
                }
                intent.putExtra("one",s);
                startActivity(intent);
            }
        });

    }
}
